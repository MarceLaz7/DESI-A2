package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Ciudad;
import model.Conexion;
import model.Evento;
import model.Usuario;

public class EventoDAO {

	private Conexion con;
	private Connection connection;
	
	public EventoDAO(String jdbcURL, String jdbcUsername, String jdbcPassword)
	{
		con = new Conexion(jdbcURL, jdbcUsername, jdbcPassword);
	}
	
	//insertar
	//recibe el objeto evento
	public boolean insertar(Evento evento) throws SQLException
	{
		//sentencia sql
		String sql = "INSERT INTO eventos (descripcion, id_ciudad) VALUES (?, ?)";
		con.conectar();  //conexion a base de datos
		
		connection = con.getJdbcConnection();  //obtenemos conexion 
		PreparedStatement statement = connection.prepareStatement(sql);  //preparamos la sentecnia
		
		//actualizamos los ? por los valores del objeto pedido
		statement.setString(1, evento.getDescripcion());
		statement.setInt(2, evento.getIdCiudad());
		
		//ejecutamos la sentecia, la cual devuelve el nuemero de registros insertados
		boolean rowInserted = statement.executeUpdate() > 0;  //si el numero es mayor a cero nos indica que el registro se agrego

		statement.close();  //cierra la sentencia 
		con.desconectar();  //cierra la conexion a base de datos
		
		return rowInserted;  //retorna el true/false indicando si logro insertar el registro o no
	}
	
	//listar ciudades
	public List<Ciudad> listarCiudades() throws SQLException
	{
		List<Ciudad> ciudades = new ArrayList<Ciudad>();  //inicializa una lista de ciudades
		String sql = "SELECT * FROM ciudades";  //creamos la sentencia sql
		
		con.conectar();  //abrimos conexion con base de datos
		connection = con.getJdbcConnection(); //obtenemos el objeto connection
		
		PreparedStatement statement = connection.prepareStatement(sql);  //prepara la sentencia 
		
		ResultSet resultSet = statement.executeQuery();  //ejecuta la sentencia en base de datos
		
		//recorrer los resultados para sacar la informacion
		while(resultSet.next())
		{
			//obtenener los valores de las columnas de cada registro
			int id = resultSet.getInt("id");
			String nombre = resultSet.getString("nombre");
			
			//crear un nuevo objeto a partir de la data del registro
			Ciudad ciudad = new Ciudad(id, nombre);
			ciudades.add(ciudad); //agregar en la lista de ciudades
		}
		
		con.desconectar();  //cierro conexion con la base de datos
		return ciudades;  //retornamos la lista
	}
	
	public List<Usuario> listarUsuarioCiudad(int id_ciudad) throws SQLException
	{
		List<Usuario> usuarios = new ArrayList<Usuario>();  //inicializa una lista de usuarios
		String sql = "SELECT * FROM usuarios WHERE id_ciudad = ?";  //creamos la sentencia sql
		
		con.conectar();  //abrimos conexion con base de datos
		connection = con.getJdbcConnection(); //obtenemos el objeto connection
		
		PreparedStatement statement = connection.prepareStatement(sql);  //prepara la sentencia 
		
		statement.setInt(1, id_ciudad);
		
		ResultSet resultSet = statement.executeQuery();  //ejecuta la sentencia en base de datos
		
		//recorrer los resultados para sacar la informacion
		while(resultSet.next())
		{
			//obtenener los valores de las columnas de cada registro
			int id = resultSet.getInt("id");
			String nombre = resultSet.getString("nombre");
			String correo = resultSet.getString("correo");
			int idCiudad = resultSet.getInt("id_ciudad");
			
			//crear un nuevo objeto a partir de la data del registro
			Usuario usuario = new Usuario(id, nombre, correo, idCiudad);
			usuarios.add(usuario); //agregar en la lista de usuarios
		}
		
		con.desconectar();  //cierro conexion con la base de datos
		return usuarios;  //retornamos la lista
	}
}
