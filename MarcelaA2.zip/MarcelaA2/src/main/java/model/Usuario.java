package model;

public class Usuario {

	private int id;
	private String nombre;
	private String correo;
	private int id_ciudad;
	
	public Usuario(String nombre, String correo, int id_ciudad) 
	{
		this(0, nombre, correo, id_ciudad);
	}
	
	public Usuario(int id, String nombre, String correo, int id_ciudad) 
	{
		this.id = id;
		this.nombre = nombre;
		this.correo = correo;
		this.id_ciudad = id_ciudad;
	}

	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}

	public String getNombre() 
	{
		return nombre;
	}
	public void setNombre(String nombre) 
	{
		this.nombre = nombre;
	}

	public String getCorreo() 
	{
		return correo;
	}
	public void setCorreo(String correo) 
	{
		this.correo = correo;
	}

	public int getIdCiudad() 
	{
		return id_ciudad;
	}
	public void setIdCiudad(int id_ciudad) 
	{
		this.id_ciudad = id_ciudad;
	}
	
}
