package model;

public class Evento {

	private int id;
	private String descripcion;
	private int id_ciudad;
	
	public Evento(String descripcion, int id_ciudad) 
	{
		this(0, descripcion, id_ciudad);
	}
	
	public Evento(int id, String descripcion, int id_ciudad) 
	{
		this.id = id;
		this.descripcion = descripcion;
		this.id_ciudad = id_ciudad;
	}

	public int getId() 
	{
		return id;
	}
	public void setId(int id) 
	{
		this.id = id;
	}

	public String getDescripcion() 
	{
		return descripcion;
	}
	public void setDescripcion(String descripcion) 
	{
		this.descripcion = descripcion;
	}

	public int getIdCiudad() 
	{
		return id_ciudad;
	}
	public void setIdCiudad(int id_ciudad) 
	{
		this.id_ciudad = id_ciudad;
	}

}
