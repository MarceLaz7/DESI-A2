package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.EventoDAO;
import model.Ciudad;
import model.Evento;
import model.Usuario;

@WebServlet("/evento")
public class EventoController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	EventoDAO eventoDAO;
	
	public void init()
	{
		String jdbcURL = getServletContext().getInitParameter("jdbcURL");
		String jdbcUsername = getServletContext().getInitParameter("jdbcUsername");
		String jdbcPassword = getServletContext().getInitParameter("jdbcPassword");
		
		try
		{
			eventoDAO = new EventoDAO(jdbcURL, jdbcUsername, jdbcPassword);
		}
		catch(Exception e)
		{
			System.out.println("Error inicializando el eventoDAO");
		}
	}
	
	public EventoController()
	{
		super();
	}
	
	/*
	 * Metodo que se ejecuta cuando se realiza una peticion
	 * */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String accion = request.getParameter("accion");  //se obtiene el parametro de la url
		
		try
		{
			switch(accion)
			{
				case "nuevo":
					nuevo(request, response);  //llama al metdo para mostrar el formulario
					break;
				case "registrar":
					registrar(request, response);  //llama al metedo de registrar un nuevo pedido
					break;
				default: 
					System.out.println("accion invalida!");
			}
		}
		catch(SQLException e)
		{
			System.out.println("Error: " + e.getMessage());
		}
		
	}

	/*
	 * Metodo que se ejecuta cuando se realiza una peticion por medio de post
	 * */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);  //llamar a la peticion get
	}
	
	private void nuevo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException 
	{
		//objeto que permite navegar entre las paginas
		RequestDispatcher dispatcher = request.getRequestDispatcher("/vista/evento/nuevo.jsp");
		List<Ciudad> listaCiudades = eventoDAO.listarCiudades();  
		request.setAttribute("lista", listaCiudades); 
		dispatcher.forward(request, response); //accion que redirige a una nueva direccion/ruta	
	}
	
	private void registrar(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException 
	{
		int idCiudad = Integer.parseInt(request.getParameter("idciudad"));
		String descripcion = request.getParameter("descripcion");
		
		Evento evento = new Evento(descripcion, idCiudad);
		
		if(eventoDAO.insertar(evento))
		{
			//obtener usuario de esa ciudad
			List<Usuario> usuarios = eventoDAO.listarUsuarioCiudad(idCiudad);
						
			//recorrer la lista y enviar mensaje a cada correo
			for(int i = 0; i < usuarios.size(); i++)
				System.out.println("Enviando correo de notificacion a: " + usuarios.get(i).getCorreo() + " (" + usuarios.get(i).getNombre() + ")");
			
			nuevo(request, response);
		}
		else
		{
			System.out.println("Error creando el evento!");
		}
	}
}
